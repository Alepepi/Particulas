﻿using Fire.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fire
{
    public partial class Form1 : Form
    {
        Canvas canvas;

        Graphics g;
        Bitmap bmp;
        Random random;

        public Form1()
        {
            InitializeComponent();
            random = new Random();
            posCursor = new Point(0, 0);
            canvas = new Canvas(pictureBox1.Width, pictureBox1.Height);
            partics = new List<Particle>();
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            limits = new Rectangle(new Point(0, 0), new Size(pictureBox1.Width, pictureBox1.Height));
            pictureBox1.Image = bmp;
            g = Graphics.FromImage(bmp);
            counter = 0;

        }

        int counter, sel;
        Brush brush;
        List<Particle> partics;
        Particle b;
        Point posCursor;
        Rectangle limits;
        public bool fire = false;
        private void pictureBox1_MouseMove_1(object sender, MouseEventArgs e)
            {
                posCursor = e.Location;
            }

        public void Render()
        {
            g.Clear(Color.Black);

            if (fire)
            {
                for (int i = 0; i < partics.Count; i++)
                {
                    if (partics[i].z < 1)
                        g.DrawImage(Resources.Flame1, partics[i].center.X, partics[i].center.Y, partics[i].radius, partics[i].radius);
                    else if (partics[i].z < 2)
                        g.DrawImage(Resources.Flame2, partics[i].center.X, partics[i].center.Y, partics[i].radius, partics[i].radius);
                    else if (partics[i].z < 3)
                        g.DrawImage(Resources.Flame1, partics[i].center.X, partics[i].center.Y, partics[i].radius, partics[i].radius);
                    else if (partics[i].z < 4)
                        g.DrawImage(Resources.Flame2, partics[i].center.X, partics[i].center.Y, partics[i].radius, partics[i].radius);
                    else
                        g.DrawImage(Resources.Flame1, partics[i].center.X, partics[i].center.Y, partics[i].radius, partics[i].radius);
                }
            }
            pictureBox1.Invalidate();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            sel = 2;
            partics.Clear();
            fire = true;
            for (int i = 0; i < 250; i++)
            {
                b = new Particle(sel, random, limits, posCursor);
                partics.Add(b);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            canvas.FastClear();
            if (fire)
            {
                for (int i = 0; i < partics.Count; i++)
                    partics[i].UpdateGen(limits, partics, random, sel, posCursor);
            }
            Render();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
